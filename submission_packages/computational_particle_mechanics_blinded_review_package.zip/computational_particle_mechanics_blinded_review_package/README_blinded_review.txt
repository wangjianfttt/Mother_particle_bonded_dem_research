Blinded-review package for Computational Particle Mechanics.

The ScienceDirect Guide for Authors states that the journal operates a double-anonymized review process.
Use 01_blinded_manuscript.pdf as the review manuscript when the live system asks for a blinded manuscript file.
Use the full author manuscript and author-details documents only for title-page, metadata or production-source roles.

Files:
- 01_blinded_manuscript.pdf: author-identifying information removed.
- 01_blinded_manuscript.tex: editable blinded LaTeX source.
- references.bib: bibliography source used by the blinded TeX file.

Author names, affiliations, e-mail address, acknowledgements, contribution statement, author-linked DOI and GitHub identifiers are absent from the blinded TeX source.
