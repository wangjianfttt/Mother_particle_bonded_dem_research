Computational Particle Mechanics upload files

Manuscript: 01_manuscript.pdf
Highlights: 02_highlights.docx
Graphical abstract: 03_graphical_abstract.png or 03_graphical_abstract.tiff
Editable graphical abstract backup: 03_graphical_abstract.pdf and 03_graphical_abstract.svg
Declaration of competing interest: 04_declaration_of_competing_interest.docx
Cover letter: 05_cover_letter.docx
Author e-mails and CRediT contributions: 06_author_emails_and_contributions.docx
LaTeX manuscript source: 07_latex_source.zip
Editorial system paste fields: 08_editorial_submission_fields.docx

Computational Particle Mechanics currently routes submissions through the Elsevier/ScienceDirect journal page.
The full reproducibility package remains submission_packages/repaired_submission_package.zip.
