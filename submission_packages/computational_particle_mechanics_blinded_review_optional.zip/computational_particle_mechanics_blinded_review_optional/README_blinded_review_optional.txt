Optional blinded-review package for Computational Particle Mechanics.

Use this package only if the live submission system requests a blinded manuscript file.
The main upload package remains submission_packages/computational_particle_mechanics_upload_ready.zip.

Files:
- 01_blinded_manuscript.pdf: author-identifying information removed.
- 01_blinded_manuscript.tex: editable blinded LaTeX source.
- references.bib: bibliography source used by the blinded TeX file.

Author names, affiliations, e-mail address, acknowledgements, contribution statement, author-linked DOI and GitHub identifiers are absent from the blinded TeX source.
