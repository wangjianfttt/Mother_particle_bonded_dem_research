Target-neutral repaired submission upload files

Manuscript: 01_manuscript.pdf
Highlights: 02_highlights.docx
Graphical abstract: 03_graphical_abstract.png or 03_graphical_abstract.tiff
Graphical abstract editable backup: 03_graphical_abstract.pdf and 03_graphical_abstract.svg
Declaration of competing interest: 04_declaration_of_competing_interest.docx
Cover letter: 05_cover_letter.docx
Author e-mails and CRediT contributions: 06_author_emails_and_contributions.docx

This upload set is generated from manuscript/repaired_full_submission_draft.md and does not reuse rejected-journal manuscript PDFs.
